﻿$ErrorActionPreference = 'Stop'
$script:form = $null
$script:timer = $null
$script:picture = $null
$script:appProcess = $null
$script:startupMutex = $null

try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $script:appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $script:exePath = Join-Path $script:appDir 'Mosca_PDF.exe'
    $script:logoPath = Join-Path $script:appDir 'Mosca_PDF_Logo.png'

    if (!(Test-Path -LiteralPath $script:exePath)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Nao encontrei o executavel do Mosca PDF:`r`n$script:exePath",
            'Mosca PDF', 'OK', 'Error'
        ) | Out-Null
        exit 1
    }

    # If the catalog is already running, do not open another copy.
    $existing = Get-Process -Name 'Mosca_PDF' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($existing) { exit 0 }

    # Numero de serie fixo deste computador (para a trava de licenca do Mosca).
    try {
        $mg = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid -ErrorAction Stop).MachineGuid
    } catch { $mg = "$env:COMPUTERNAME|$env:USERNAME" }
    try {
        $seed = 'MOSCA|' + $mg
        $sha  = [System.Security.Cryptography.SHA256]::Create()
        $hash = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($seed))
        $hex  = (($hash | ForEach-Object { $_.ToString('x2') }) -join '').Substring(0,40)
        [System.IO.File]::WriteAllText((Join-Path $script:appDir 'device-id.txt'), $hex)
    } catch {}

    # Launch the catalog before the splash animation, so the splash cannot block startup.
    try {
        $script:appProcess = Start-Process -FilePath $script:exePath -WorkingDirectory $script:appDir -PassThru
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Nao foi possivel iniciar o catalogo:`r`n$($_.Exception.Message)",
            'Mosca PDF', 'OK', 'Error'
        ) | Out-Null
        exit 1
    }

    $script:form = New-Object System.Windows.Forms.Form
    $script:form.Text = 'Mosca PDF'
    $script:form.StartPosition = 'CenterScreen'
    $script:form.FormBorderStyle = 'FixedDialog'
    $script:form.MaximizeBox = $false
    $script:form.MinimizeBox = $false
    $script:form.ShowInTaskbar = $false
    $script:form.TopMost = $true
    $script:form.ClientSize = New-Object System.Drawing.Size(500, 520)
    $script:form.BackColor = [System.Drawing.Color]::FromArgb(20, 20, 22)
    $script:form.ForeColor = [System.Drawing.Color]::White

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'MOSCA PDF'
    $title.Font = New-Object System.Drawing.Font('Segoe UI', 22, [System.Drawing.FontStyle]::Bold)
    $title.ForeColor = [System.Drawing.Color]::FromArgb(232, 177, 55)
    $title.TextAlign = 'MiddleCenter'
    $title.Location = New-Object System.Drawing.Point(20, 18)
    $title.Size = New-Object System.Drawing.Size(460, 44)
    $script:form.Controls.Add($title)

    $script:picture = New-Object System.Windows.Forms.PictureBox
    $script:picture.Location = New-Object System.Drawing.Point(55, 68)
    $script:picture.Size = New-Object System.Drawing.Size(390, 340)
    $script:picture.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $script:picture.BackColor = $script:form.BackColor
    if (Test-Path -LiteralPath $script:logoPath) {
        $script:picture.Image = [System.Drawing.Image]::FromFile($script:logoPath)
    }
    $script:form.Controls.Add($script:picture)

    $script:status = New-Object System.Windows.Forms.Label
    $script:status.Text = 'Iniciando o catalogo tecnico...'
    $script:status.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $script:status.ForeColor = [System.Drawing.Color]::FromArgb(230, 230, 230)
    $script:status.TextAlign = 'MiddleCenter'
    $script:status.Location = New-Object System.Drawing.Point(20, 414)
    $script:status.Size = New-Object System.Drawing.Size(460, 28)
    $script:form.Controls.Add($script:status)

    $script:bar = New-Object System.Windows.Forms.ProgressBar
    $script:bar.Location = New-Object System.Drawing.Point(45, 452)
    $script:bar.Size = New-Object System.Drawing.Size(410, 18)
    $script:bar.Minimum = 0
    $script:bar.Maximum = 100
    $script:bar.Value = 3
    $script:bar.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
    $script:form.Controls.Add($script:bar)

    $small = New-Object System.Windows.Forms.Label
    $small.Text = 'Preparando sua area de trabalho'
    $small.Font = New-Object System.Drawing.Font('Segoe UI', 8)
    $small.ForeColor = [System.Drawing.Color]::FromArgb(160, 160, 160)
    $small.TextAlign = 'MiddleCenter'
    $small.Location = New-Object System.Drawing.Point(20, 478)
    $small.Size = New-Object System.Drawing.Size(460, 22)
    $script:form.Controls.Add($small)

    $script:progress = 3
    $script:timer = New-Object System.Windows.Forms.Timer
    $script:timer.Interval = 100
    $script:timer.Add_Tick({
        try {
            $script:progress = [Math]::Min(100, $script:progress + 4)
            $script:bar.Value = $script:progress
            if ($script:progress -ge 100) {
                $script:timer.Stop()
                $script:status.Text = 'Pronto!'
                $script:form.Refresh()
                $script:closeTimer = New-Object System.Windows.Forms.Timer
                $script:closeTimer.Interval = 300
                $script:closeTimer.Add_Tick({
                    $script:closeTimer.Stop()
                    $script:closeTimer.Dispose()
                    $script:form.Close()
                })
                $script:closeTimer.Start()
            }
        } catch {
            try { $script:timer.Stop() } catch {}
            try { $script:form.Close() } catch {}
        }
    })

    $script:form.Add_Shown({ $script:timer.Start() })
    [void]$script:form.ShowDialog()
}
catch {
    [System.Windows.Forms.MessageBox]::Show(
        "Ocorreu um erro ao abrir o Mosca PDF:`r`n$($_.Exception.Message)",
        'Mosca PDF', 'OK', 'Error'
    ) | Out-Null
}
finally {
    try { if ($script:timer) { $script:timer.Stop(); $script:timer.Dispose() } } catch {}
    try { if ($script:picture -and $script:picture.Image) { $script:picture.Image.Dispose() } } catch {}
    try { if ($script:form) { $script:form.Dispose() } } catch {}
}

Option Explicit
Dim shell, fso, appDir, psPath, cmd
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)
psPath = fso.BuildPath(appDir, "Inicializacao_Mosca_PDF.ps1")
If Not fso.FileExists(psPath) Then
  MsgBox "Não encontrei os arquivos de inicialização do Mosca PDF em:" & vbCrLf & appDir, vbCritical, "Mosca PDF"
  WScript.Quit 1
End If
shell.CurrentDirectory = appDir
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & psPath & Chr(34)
shell.Run cmd, 0, False

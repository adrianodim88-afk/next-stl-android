﻿$ErrorActionPreference = 'Stop'
$appDir = Join-Path $env:LOCALAPPDATA 'MoscaPDF'
$launcher = Join-Path $appDir 'Start_Mosca_PDF.vbs'
$ico = Join-Path $appDir 'Mosca_PDF.ico'
foreach ($p in @($launcher, $ico, (Join-Path $appDir 'Adriano_Dim_Modelagem_3D.html'))) {
  if (-not (Test-Path -LiteralPath $p)) { throw "Arquivo necessário não encontrado: $p" }
}
$candidates = @()
try {
  $d = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
  if ($d) { $candidates += $d }
} catch {}
if ($env:USERPROFILE) { $candidates += (Join-Path $env:USERPROFILE 'Desktop') }
if ($env:OneDrive) { $candidates += (Join-Path $env:OneDrive 'Desktop') }
if ($env:PUBLIC) { $candidates += (Join-Path $env:PUBLIC 'Desktop') }
$candidates = $candidates | Where-Object { $_ } | Select-Object -Unique
$wsh = New-Object -ComObject WScript.Shell
$created = @()
foreach ($desktop in $candidates) {
  try {
    if (-not (Test-Path -LiteralPath $desktop)) { New-Item -ItemType Directory -Path $desktop -Force | Out-Null }
    $link = Join-Path $desktop 'Mosca PDF.lnk'
    $sc = $wsh.CreateShortcut($link)
    $sc.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
    $sc.Arguments = '"' + $launcher + '"'
    $sc.WorkingDirectory = $appDir
    $sc.IconLocation = "$ico,0"
    $sc.Description = 'Mosca PDF - Catálogo Técnico'
    $sc.Save()
    if (Test-Path -LiteralPath $link) { $created += $link }
  } catch {}
}
if ($created.Count -eq 0) { throw 'O Windows não confirmou a criação do atalho na Área de Trabalho.' }
Write-Host 'Atalho criado:'; $created | ForEach-Object { Write-Host $_ }

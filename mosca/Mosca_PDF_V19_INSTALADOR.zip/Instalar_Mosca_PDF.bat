﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "APPDIR=%LOCALAPPDATA%\MoscaPDF"
set "SOURCE=%~dp0"
echo.
echo =============================================
echo       MOSCA PDF - CATALOGO TECNICO V18.2
echo =============================================
echo.
for %%F in (Mosca_PDF.exe Adriano_Dim_Modelagem_3D.html Mosca_PDF.ico Mosca_PDF_Logo.png Start_Mosca_PDF.vbs Inicializacao_Mosca_PDF.ps1 Criar_Atalho.ps1) do if not exist "%SOURCE%%%F" goto ERRO_ARQUIVOS
if not exist "%APPDIR%" mkdir "%APPDIR%"
if errorlevel 1 goto ERRO_COPIA
for %%F in (Mosca_PDF.exe Adriano_Dim_Modelagem_3D.html Mosca_PDF.ico Mosca_PDF_Logo.png Start_Mosca_PDF.vbs Inicializacao_Mosca_PDF.ps1) do (
  copy /Y "%SOURCE%%%F" "%APPDIR%\%%F" >nul
  if errorlevel 1 goto ERRO_COPIA
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%SOURCE%Criar_Atalho.ps1"
if errorlevel 1 goto ERRO_ATALHO
echo.
echo =============================================
echo  INSTALACAO CONCLUIDA!
echo  Atalho Mosca PDF criado na Area de Trabalho.
echo =============================================
echo.
pause
exit /b 0
:ERRO_ARQUIVOS
echo ERRO: Extraia TODOS os arquivos do ZIP antes de instalar.
goto FIM_ERRO
:ERRO_COPIA
echo ERRO: Nao foi possivel copiar os arquivos para %APPDIR%.
goto FIM_ERRO
:ERRO_ATALHO
echo ERRO: O Windows nao confirmou a criacao do atalho.
echo Confira a Area de Trabalho e tente novamente.
:FIM_ERRO
echo.
pause
exit /b 1

﻿@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=@([Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory),(Join-Path $env:USERPROFILE 'Desktop'),(Join-Path $env:OneDrive 'Desktop'),(Join-Path $env:PUBLIC 'Desktop'))|Where-Object {$_}|Select-Object -Unique;foreach($d in $c){$p=Join-Path $d 'Mosca PDF.lnk';if(Test-Path -LiteralPath $p){Remove-Item -LiteralPath $p -Force}}"
if exist "%LOCALAPPDATA%\MoscaPDF" rmdir /s /q "%LOCALAPPDATA%\MoscaPDF"
echo Mosca PDF removido deste computador.
pause
